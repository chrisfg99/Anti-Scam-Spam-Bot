#Candidate Number 184521
#University of Sussex

import nltk
import csv
import ast
import collections
from nltk.metrics.scores import (precision, recall, f_measure)
#from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn import ensemble
import pandas as pd

#Class that shall be used for the creation of classifiers and classification of data
class Classifier:
    def __init__(self,retraining_data):
        #initialise needed variables
        self.retraining_data=retraining_data


    #Function to get data from CSV files and compile it into a dataset variable
    #Structure of dataset variable for 1 email would be; ({Word1:Freq.Word1,Word2:Freq.Word2,Word3:Freq.Word3},Tag)
    def Create_Dataset(self):
        #Get spam Datasets using spam ham, processed email and questionnaire csv files
        #Also get the vectors made from spam ham and fraud email datasets
        spam_Dataset_reader,dataSetSpam = csv.reader(open('Controller/PreProcessor/spam_ham_dataset_cleaned.csv', 'rU')),[]
        spam_Dataset_reader2 = csv.reader(open('Controller/PreProcessor/processedEmails_cleaned.csv', 'rU'))
        spam_Dataset_reader3 = csv.reader(open('Controller/PreProcessor/questionaireSpam_cleaned.csv', 'rU'))
        self.spamVector = pd.read_csv(open('Controller/PreProcessor/spam_ham_dataset_vector.csv', 'rU'))


        #Get scam Datasets using fraud email and questionnaire csv files
        # Also get the vectors made from these datasets
        scam_Dataset_reader,dataSetScam = csv.reader(open('Controller/PreProcessor/fraud_email_cleaned.csv', 'rU')),[]
        scam_Dataset_reader2 = csv.reader(open('Controller/PreProcessor/questionaireScam_cleaned.csv', 'rU'))
        self.scamVector = pd.read_csv(open('Controller/PreProcessor/fraud_email_vector.csv', 'rU'))


        print("      Creating training data")

        #spam data set readers
        for line in spam_Dataset_reader:
            dataset_subject,dataset_tags, = (line[1]),(line[5])
            dataSetSpam.append((dataset_subject,dataset_tags))

        for line in spam_Dataset_reader2:
            dataset_subject,dataset_tags, = (line[1]),(line[5])
            dataSetSpam.append((dataset_subject,dataset_tags))

        for line in spam_Dataset_reader3:
            dataset_subject,dataset_tags, = (line[1]),(line[5])
            dataSetSpam.append((dataset_subject,dataset_tags))

        #scam data set readers
        for line in scam_Dataset_reader:
            dataset_subject,dataset_tags = (line[1]),(line[5])
            dataSetScam.append((dataset_subject, dataset_tags))


        #If dataset_made = 1 then add the retraining data as some will now exist
        if self.retraining_data==1:
            print("      Adding retraining data")
            retrain_reader = csv.reader(open('Controller/tagged_data.csv', 'rU'))
            if retrain_reader!=None or retrain_reader!="":
                for line in retrain_reader:
                    dataset_subject, dataset_body, dataset_tags = (line[1]),(line[3]),(line[5])
                    dataSpam,dataScam = (dataset_subject, dataset_tags),(dataset_body,dataset_tags)
                    dataSetSpam.append(dataSpam),dataSetScam.append(dataScam)

        #split the dataset into training and testing
        self.spam_training_data,self.scam_training_data=dataSetSpam[300:],dataSetScam[300:]
        self.spam_training_data2, self.scam_training_data2 = self.spamVector[300:],self.scamVector[300:]
        print(" Spam Training data length =",len(self.spam_training_data))
        print(" Scam Training data length =", len(self.scam_training_data))
        print("__________________________________")
        self.spam_test_data,self.scam_test_data = self.stringDictionary(dataSetSpam[:299]),self.stringDictionary(dataSetScam[:299])
        self.spam_test_data2, self.scam_test_data2 = self.spamVector[:299],self.scamVector[:299]


    #helper function to convert strings structured like dicts into type string
    def stringDictionary(self, stringToConvert):
        dictionary = []
        for features, label in stringToConvert[1:]:
            dictionary.append((ast.literal_eval(features), label))

        return dictionary


    #Function that gets the dataSet and then trains the classifier
    def train(self):
        #get datasets
        self.Create_Dataset()
        spamTrainingValid = self.stringDictionary(self.spam_training_data)
        scamTrainingValid = self.stringDictionary(self.scam_training_data)
        stringSpam, stringScam=self.dictToString(spamTrainingValid),self.dictToString(scamTrainingValid)

        #train spam classifier
        self.spamClassifier1,y = nltk.NaiveBayesClassifier.train(spamTrainingValid),[]
        self.spamClassifier2 = nltk.classify.scikitlearn.SklearnClassifier(SVC(max_iter=10000,probability=True)).train(spamTrainingValid)
        #for message in spamTrainingValid:
        #    y.append(message[1])
        #self.spamClassifier3 = ensemble.RandomForestClassifier(n_estimators = 1000, random_state = 42)
        #self.spamClassifier3.fit(self.spam_training_data2, y[300:5172])
        #self.spamClassifier4 = (DecisionTreeClassifier(max_depth=100))
        #self.spamClassifier4.fit(self.spam_training_data2,y[300:5172])

        #train scam classifier
        #self.scamClassifier1 = nltk.NaiveBayesClassifier.train(scamTrainingValid)
        self.scamClassifier2,y2 = nltk.classify.scikitlearn.SklearnClassifier(SVC(max_iter=10000,probability=True)).train(scamTrainingValid),[]
        for message in scamTrainingValid:
            y2.append(message[1])
        self.scamClassifier3 = ensemble.RandomForestClassifier(n_estimators = 1000, random_state = 42)
        self.scamClassifier3.fit(self.scam_training_data2[:11327],y2[300:])
        #self.scamClassifier4 = (DecisionTreeClassifier(max_depth=100))
        #self.scamClassifier4.fit(self.scam_training_data2[:11327],y2[300:])



    #function that classifies an email by taking it as clean text and running it against classifiers
    def classify(self,cleanTxt,subjectvectors,bodyvectors):
        tagged = cleanTxt
        for i in range(len(cleanTxt)):
            # get raw probabilities
            subjectProbab=self.getItems((self.spamClassifier1.prob_classify(cleanTxt[i][0])))
            subjectProbab2 = self.getItems((self.spamClassifier2.prob_classify(cleanTxt[i][0])))
            #subjectProbab3 = self.convertProbabs(self.spamClassifier3.predict_proba(subjectvectors)[i],"spam")
            #subjectProbab4 = self.convertProbabs(self.spamClassifier4.predict_proba(subjectvectors)[i],"spam")
            subjectProbab = self.addProbabs(subjectProbab, subjectProbab2)
            #subjectProbab2 = self.addProbabs(subjectProbab4, subjectProbab3)
            #subjectProbab = self.addProbabs(subjectProbab, subjectProbab2)

            #bodyProbab=self.getItems((self.scamClassifier1.prob_classify(cleanTxt[i][2])))
            bodyProbab2 =self.getItems((self.scamClassifier2.prob_classify(cleanTxt[i][2])))
            bodyProbab3 = self.convertProbabs(self.scamClassifier3.predict_proba(bodyvectors)[i], "scam")
            #bodyProbab4 = self.convertProbabs(self.scamClassifier4.predict_proba(bodyvectors)[i], "scam")
            #bodyProbab=self.addProbabs(bodyProbab,bodyProbab2)
            #bodyProbab2 = self.addProbabs(bodyProbab3, bodyProbab4)
            bodyProbab = self.addProbabs(bodyProbab3, bodyProbab2)

            # calculate final probabilities
            tag,probabDict,probabList=self.calcProbabs(subjectProbab, bodyProbab)

            #output probabilities and tags
            print("Email; ",cleanTxt[i][6],"is",tag,'with probabilities;')
            print(probabDict)

            #enter tags and probabilities into tagged list
            tagged[i]=tagged[i][0],tagged[i][1],tagged[i][2],tagged[i][3],tag,probabList,tagged[i][6]

        #allow for retraining data to be added
        self.retraining_data = 1
        self.tagged=tagged

        return tagged


    #Useful function to get items from dictionary
    #Lowers repetitive code
    def getItems(self,dist):
        probabs={}
        for label in dist.samples():
            probabs[label]=dist.prob(label) * 100
        return probabs


    #Function made to take elements of a dictionary and turn it into a string
    def dictToString(self,dataset):
        string, tags, line = [], [],[]
        for i in range(len(dataset)):
            string= []
            for word in dataset[i][0]:
                string.append(word)
            if(dataset[i][1]=="scam" or dataset[i][1]=="spam"):
                tags.append(1)
            else:
                tags.append(0)
            line.append([string])

        return [line,[tags]]


    #Function that takes all probabilities and calculates their totals
    #must be submited as subject and then body probabilities
    def calcProbabs(self,spamProbabs,scamProbabs):
        ham,probabDict,best,probabList,tag=0,{},0,[],'ham'
        #if label
        #Ham probabs adjusted for bias reasons
        for label in spamProbabs:
            if label=='ham':
                ham=ham+(spamProbabs['ham']*0.9)
            elif label=='spam':
                probabDict['spam']=(spamProbabs['spam']/1.9)
                probabList.append('%s:%f' % ('spam', probabDict['spam']))
                if probabDict['spam']>best:
                    best,tag= probabDict['spam'],'spam'

        for label in scamProbabs:
            if label == 'ham':
                ham = ham+(scamProbabs['ham']*0.9)
            elif label=='scam':
                probabDict['scam']=(scamProbabs['scam']/1.9)
                probabList.append('%s:%f'% ('scam',probabDict['scam']))
                if (probabDict['scam'])>best:
                    best,tag=(probabDict['scam']),'scam'
        probabDict['ham']=(ham/2)
        probabList.append('%s:%f'% ('ham',probabDict['ham']))

        if (ham/2)>best:
            tag='ham'

        return tag,probabDict,probabList


    #Function to add probabilities together
    def addProbabs(self,p1,p2):
        for word in p1:
            p1[word]=(p1[word]+p2[word])/2#/1.4215
        #print(p1)
        return p1

    #Function to convert list of probs to dict of probs
    def convertProbabs(self,probs,word):
        dict={}
        dict["ham"]=probs[0]*100
        dict[word]=probs[1]*100
        return dict

    #Function that measures the success of a classifier and prints all possible measures
    def getMeasures(self,testData,pos,name,classifier1=None,classifier2=None,classifier3=None,classifier4=None,testData2=None):
        refsets = collections.defaultdict(set)
        testsets = collections.defaultdict(set)

        for i, (feats, label) in enumerate(testData):
            refsets[label].add(i)
            if classifier1!=None:
                probab1 = self.getItems(classifier1.prob_classify(feats))
                #probab1 = self.convertProbabs(classifier1.predict_proba(feats),pos)
                valueHam = (probab1["ham"])
            if classifier2!=None:
                probab2 = self.getItems(classifier2.prob_classify(feats))
                #probab2 = self.convertProbabs(classifier2.predict_proba(testData2)[i], pos)
                valueHam=(probab1["ham"]+(probab2["ham"]*100))/2
            if classifier3!=None:
                #probab3 = self.getItems(classifier3.prob_classify(feats))
                probab3 = self.convertProbabs(classifier3.predict_proba(testData2)[i], pos)
                valueHam = (probab1["ham"] + (probab2["ham"]*100) + (probab3["ham"]*100))/3
            if classifier4!=None:
                #probab4 = self.getItems(classifier3.prob_classify(feats))
                probab4 = self.convertProbabs(classifier4.predict_proba(testData2)[i], pos)
                valueHam = (probab1["ham"] + probab2["ham"] + (probab4["ham"]*100) + (probab3["ham"]*100))/4
            if valueHam>50:
                observed="ham"
            else:
                observed=pos
            #print(observed,label)
            testsets[observed].add(i)

        print(name,"Classifier")
        print("Accuracy:", nltk.classify.accuracy(classifier1, testData))
        print('Recall:', recall(refsets[pos], testsets[pos]))
        print('Precision:', precision(refsets[pos], testsets[pos]))
        print("F-Measure:", f_measure(refsets[pos], testsets[pos]))
        #print(classifier.most_informative_features(20))
        print("__________________________________")