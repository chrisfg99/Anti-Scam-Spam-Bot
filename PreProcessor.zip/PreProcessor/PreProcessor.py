#Candidate Number 184521
#University of Sussex

#file for the Pre-Processor Class
import csv

from nltk.corpus import (stopwords,wordnet as wn)
from nltk.stem import WordNetLemmatizer
import re

class PreProcessor:

    def __init__(self):
        # initialise pre processor class's variables
        self.tags = "abbr | area |w-auto | base | bdo | blockquote | br | button | caption | cite | code | col | colgroup | dd | del | dfn | div | dl | DOCTYPE | dt | em | fieldset | form | h1 | h2 | h3 | h4 | h5 | h6 | head | html | hr | i | img | input | ins | kbd | label | legend |-left | li | link | map | meta | noscript | object | ol | optgroup | option | p | px | param | pre | q | samp | script | select | small | span | strong | style | sub | sup |-right | table | tbody | td | textarea | tfoot | th  |  thead  |  title | tr | tt | ul | var"
        self.t = 0


    #function that calls each stage of the cleaning process and passes the messages between them
    def clean(self,messages):
        stageOne=self.getLinks(messages)
        stageTwo=self.removeHTML(stageOne)
        stageThree=self.tokenise(stageTwo)
        self.t = 1
        stageFour=self.removeStop(stageThree)
        stageFive = self.tokenise(stageFour)
        stageSix = self.removeSymbols(stageFive)
        stageSeven=self.lemmatize(stageSix)
        stageEight=self.getFrequencies(stageSeven)
        cleanTxt=self.getNouns(stageEight)

        subjectvectors,bodyvectors = self.getWordVectors(cleanTxt)
        return cleanTxt,subjectvectors,bodyvectors


    #function to get all links in one place
    def getLinks(self,messages):
        length=range(len(messages))
        for i in length:
            for part in messages[i][2]:
                links=re.search("(?P<url>https?://[^\s]+)", str(part))
                if links==None:
                    messages[i][3].append("No links")
                else:
                    links=links.group("url")
                    links = re.sub(("\r.*?\r"), "", str(links))
                    messages[i][3].append(links)
        return messages


    #function to remove all HTML
    def removeHTML(self,messages):
        for i in range(len(messages)):
            body=[]
            for part in messages[i][2]:
                cleaned_part=re.sub("<.*?>|&([a-z0-9]+|#[0-9]{1,6}|#x[0-9a-f]{1,6});|(?P<url>https?://[^\s]+)", "", str(part))
                cleaned_part = re.sub(self.tags, "",str(cleaned_part))
                body.append(cleaned_part)
            messages[i] = messages[i][0], messages[i][1], body, messages[i][3], messages[i][4],[],messages[i][0]
        return messages


    #function to tokenise words in Subject and Body
    def tokenise(self,messages):
        for i in range(len(messages)):
            #tokenise body
            tokenised_body,tokenised_subject = [], []
            for part in messages[i][2]:
                tokens=part.split()
                tokenised_body.append(tokens)

            #tokenise subject
            if self.t==0:
                subject=messages[i][0]
                tokens=subject.split()
                tokenised_subject.append(tokens)
            else:
                tokenised_subject=messages[i][0]

            #compile
            messages[i]=tokenised_subject,messages[i][1],tokenised_body,messages[i][3],messages[i][4],[],messages[i][6]
        return messages


    #function to remove any stop words in the text
    def removeStop(self,messages):
        stop_words = set(stopwords.words('english'))
        for i in range(len(messages)):
            filtered_body,filtered_subject = [], []

            #filter stop words from body
            for part in messages[i][2]:
                for word in part:
                    if word not in stop_words:
                        word=re.sub(r"[^\x00-\x7F]+|\\n|\\.*?\\x*?|\\\.*?\\\n|\\.*?\\n|\\t| n", " ",str(word))
                        if word!="":
                            filtered_body.append(word)

            #filter stopwords from subject
            for part in messages[i][0]:
                for word in part:
                    #print(word)
                    if word not in stop_words:
                        word=re.sub(r"[^\x00-\x7F]+|\\n|\\.*?\\x*?|\\\.*?\\\n|\\.*?\\n|\\t| n", " ",str(word))
                        if word!="":
                            filtered_subject.append(word)
            messages[i]=filtered_subject,messages[i][1],filtered_body,messages[i][3],messages[i][4],[],messages[i][6]
        return messages


    #function to remove symbols
    def removeSymbols(self,messages):
        for i in range(len(messages)):
            filtered_body,filtered_subject = [], []
            #filter body
            for part in messages[i][2]:
                for word in part:
                    word = re.sub(r"[\\~#%&*{}/:<>?|\"-.]|'n'| ", "", str(word))
                    if word!="" or word!="n":
                        filtered_body.append(word)
            #filter subject
            for word in messages[i][0]:
                word = re.sub(r"[\\~#%&*{}/:<>?|\"-.]|'n'| ", "", str(word))
                if word != "" or word != "n":
                    filtered_subject.append(word)
            messages[i]=filtered_subject,messages[i][1],filtered_body,messages[i][3],messages[i][4],[],messages[i][6]
        return messages


    def lemmatize(self,messages):
        for i in range(len(messages)):
            lemmatized_body,lemmatized_subject = [], []

            #lemmatize subject
            for word in messages[i][0]:
                lemmatized_subject.append(WordNetLemmatizer.lemmatize(self,word=word))

            messages[i]=lemmatized_subject,messages[i][1],messages[i][2],messages[i][3],messages[i][4],[],messages[i][6]
        return messages


    #function to get the frequency that each word appears in a message
    def getFrequencies(self, messages):
        for i in range(len(messages)):
            #get frequency of words in subject AND BODY
            subject_frequency,body_frequency = {},{}
            for word in messages[i][0]:
                if (word.isnumeric() == True):
                    subject_frequency['Number'] = messages[i][0].count(word)
                else:
                    subject_frequency[word] = messages[i][0].count(word)
            for word in messages[i][2]:
                if (word.isnumeric() == True):
                    body_frequency['Number'] = messages[i][0].count(word)
                else:
                    body_frequency[word] = messages[i][0].count(word)

            messages[i]=subject_frequency,messages[i][1],body_frequency,messages[i][3],messages[i][4],[],messages[i][6],messages[i][0],messages[i][2]

        return messages

    def getNouns(self, messages):
        for i in range(len(messages)):
            subject,body = {},{}
            for word in messages[i][0]:
                pos_l = set()
                for tmp in wn.synsets(word):
                    if tmp.name().split('.')[0] == word:
                        pos_l.add(tmp.pos())
                # if(pos_l.__contains__('n') or pos_l.__contains__('v')  or pos_l.__contains__('a')  or pos_l.__contains__('r') ):
                #if (pos_l == {'n'} or pos_l == {'v'} or pos_l == {'n', 'v'} or pos_l == {'a'} or pos_l == {'a','v'} or pos_l == {'n', 'a'} or pos_l == {'n', 'v', 'a'}):
                if (pos_l.__contains__('n')):
                    subject[word] = messages[i][0][word]

            for word in messages[i][2]:
                pos_l = set()
                for tmp in wn.synsets(word):
                    if tmp.name().split('.')[0] == word:
                        pos_l.add(tmp.pos())
                #if((pos_l.__contains__('n') or pos_l.__contains__('v')  or pos_l.__contains__('a'))and len(word)>=2):
                if (pos_l == {'n'} or pos_l == {'v'} or pos_l=={'a'} or pos_l == {'n', 'v'} and len(word)>=2):
                #if(pos_l.__contains__('n')and len(word)>=2):
                    body[word] = messages[i][2][word]

            messages[i]=subject,messages[i][1],body,messages[i][3],messages[i][4],[],messages[i][6],messages[i][7],messages[i][8]
        return messages

    def getWordVectors(self, messages):
        # get indexes
        index_reader = csv.reader(open('Controller/PreProcessor/index.csv', 'rU'))
        lineno=0
        for line in index_reader:
            if lineno==0:
                spamIndex=line
                lineno=lineno+1
            else:
                scamIndex=line

        #get vectors
        subject_vectors,body_vectors=[],[]
        for i in range(len(messages)):
            subvec,bodvec=[],[]
            for word in spamIndex:
                if word in messages[i][7]:
                    subvec.append(1)
                else:
                    subvec.append(0)
            for word in scamIndex:
                if word in messages[i][8]:
                    bodvec.append(1)
                else:
                    bodvec.append(0)
            subject_vectors.append(subvec)
            body_vectors.append(bodvec)
        return subject_vectors, body_vectors