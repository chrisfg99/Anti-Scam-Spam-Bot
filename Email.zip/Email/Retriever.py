#Candidate Number 184521
#University of Sussex

import imaplib
import email
from email.header import decode_header
import webbrowser
import os
import csv

class Retriever:
    #initialise variables
    def __init__(self):
        # initialise account details
        details=open("Controller\Email\Details.txt", "r").readlines()
        login=details[0].split(";")
        username,password = login[0],login[1]

        #counter to keep track of emails gotten
        self.emails_read=0

        #list to store any new messages
        self.new_messages=[]

        # create IMAP4 class
        self.imap = imaplib.IMAP4_SSL("imap.gmail.com")

        # sign in to account
        self.imap.login(username, password)


    #function that opens the inbox
    def openInbox(self):
        # list to store any new messages
        self.new_messages = []

        #list all inboxes available
        self.imap.list()

        #select an inbox
        status, messages = self.imap.select("INBOX")

        # all emails
        noMessages = int(messages[0])
        print("__________________________________")
        print("          Inbox Opened")
        print("There are ",noMessages," emails in the inbox")

        # number of top emails to fetch
        N=noMessages-self.emails_read
        self.emails_read=noMessages
        #N = 1
        print("There are ", N, "new emails to be read")
        print("__________________________________")

        for i in range(noMessages, noMessages-N, -1):
            # fetch the email message by ID, using standard format
            res, msg = self.imap.fetch(str(i), "(RFC822)")
            self.new_messages.append(self.get_message(msg))
        return self.new_messages

    def get_new_messages(self):
        return self.new_messages

    def get_message(self,msg):
        msg=self.get_msg(msg)
        subject=self.decode_subject(msg)
        sender=self.decode_sender(msg)
        if msg.is_multipart()==False:
            body=self.decode_body(msg)
        else:
            body=self.decode_multibody(msg)
        if body!=None:
            return subject,[sender],body,[],[]
        else:
            return subject,[sender],[],[],[]

    def get_msg(self,msg):    
        for response in msg:
            if isinstance(response, tuple):
                # parse bytes from email into a message object
                msg = email.message_from_bytes(response[1])
        return msg

    def decode_subject(self,msg):
        subject, encoding = decode_header(msg["Subject"])[0]
        if isinstance(subject, bytes):
                    # if it's a bytes, decode to str
                    subject = subject.decode(encoding)
        return subject

    def decode_sender(self,msg):
        sender, encoding = decode_header(msg.get("From"))[0]
        if isinstance(sender, bytes):
            sender = sender.decode(encoding)
        return sender

    def decode_body(self,msg):
        # extract content type of email
        content_type = msg.get_content_type()
        # get the email body
        body = msg.get_payload(decode=True).decode()
        if content_type == "text/plain":
            return body

    def decode_multibody(self,msg):
        #iterate through different parts
        body=[]
        for part in msg.walk():
            #extract content type of email
            content_type = part.get_content_type()
            #content_disposition = str(part.get("Content-Disposition"))
            # get the email body
            part = part.get_payload(decode=True)#.decode()
            if part!=None:
                body.append(part)
        return body