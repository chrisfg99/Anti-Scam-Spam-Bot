#Candidate Number 184521
#University of Sussex

import smtplib, ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

#Sender class is in charge of returning emails to the user
class Sender:

    def __init__(self):
        # initialise account details
        details=open("Controller/Email/Details.txt", "r").readlines()
        login=details[0].split(";")
        self.username,self.password = login[0],login[1]


    #function to retrieve parts of tagged data, add them to an email and the send it
    def send(self,taggedData):
        #get components for email
        for i in range(len(taggedData)):
            tag,probabs,reciever,subjectDict,subject=taggedData[i][4],taggedData[i][5],taggedData[i][1],taggedData[i][6],["Reply from isThisScamOrSpam about: "]
            subject.append(subjectDict)
            subject=(" ".join(subject))

            #create email
            message=self.createEmail(tag,probabs,reciever,subject)

            #send email
            self.sendEmail(message,reciever)
        print("         Responses Sent")


    #function for creating the email
    def createEmail(self,tag,probabs,reciever,subject):
        #create all needed parts for the email
        message = MIMEMultipart()
        message['From'] = self.username
        message['To'] = reciever[0]
        message['Subject'] = subject
        plainText,htmlText=self.generateBody(tag,probabs)

        #add the HTML and plainText parts to message
        message.attach(plainText)
        #message.attach(htmlText)

        #message=plainText
        return message


    # function for generating the main body of the email
    def generateBody(self,tag,probabs):
        #Generate plain text for the email
        if tag=='ham':
            text = """      Hello User,
                I have determined that this email is most likely to be {tagHere}
             
            The probabilities for each tag were;
                |{probab1Here}% | {probab2Here}%| {probab3Here}%|
            If probabilities are close together consider if you were expecting the email
            
            Definitions:
                Scam: Otherwise known as Phising emails, these look to try to trick you into giving something of value 
                    whether this is information, money or something else.
                Spam: Otherwise known as junk mail, are unwanted emails sent by companies or people unknown to you
                    usually to sell a product or waste your time
                Ham: Otherwise known as a normal email, it was likely you were expecting this, it was from someone you 
                    know or for something that you want and has been deemed neither Scam nor Spam
             
             You received this email because you forwarded me an email to check if it was Spam, Scam or Ham
             Thank You for using this Service
              Yours Faithfully,
                Anti Scam/Spam Bot""".format(tagHere=tag,probab1Here=probabs[0],probab2Here=probabs[1],probab3Here=probabs[2])
            #Generate html for the email
            html = """<html><body>
                <p>Hello User,<br>
                   Your sent email has been tagged as {tag}<br>
                    The probabilities for these tags are as follows<br>
                                {probabs}
                    Thank You for using this Service<br>
                Yours Faithfully,<br>
                    Anti Scam/Spam Bot
                </p></body></html>"""
        else:
            text = """      Hello User,
                I have determined that this email is most likely to be {tagHere}
             
            The probabilities for each tag were;
                |{probab1Here}% | {probab2Here}%| {probab3Here}%|
            If probabilities are close together consider if you were expecting the email
            
            Definitions:
                Scam: Otherwise known as Phising emails, these look to try to trick you into giving something of value 
                    whether this is information, money or something else.
                Spam: Otherwise known as junk mail, are unwanted emails sent by companies or people unknown to you
                    usually to sell a product or waste your time
                Ham: Otherwise known as a normal email, it was likely you were expecting this, it was from someone you 
                    know or for something that you want and has been deemed neither Scam nor Spam
                     
            
            To add this email address to your spam filter follow the tutorial provided below:
            
                Gmail:
                
                    1. Log into your Gmail Account
                    2. Find the associated email
                    3. Open the email
                    4. At the top of the email below the subject on the right hand side are three vertical dots, click them
                    5. A drop down shall open, select either Report Spam for spam or Report Phishing for Scam as indicated by the probabilities above
                    
                Outlook/Hotmail:
                
                    1. Log into your Account
                    2. Find the associated email
                    3. Open the email
                    4. At the top of the email above the subject on the right hand side are three horizontal dots, click them
                    5. A drop down shall open, select Report Junk
             
             You received this email because you forwarded me an email to check if it was Spam, Scam or Ham
             Thank You for using this Service
              Yours Faithfully,
                Anti Scam/Spam Bot""".format(tagHere=tag, probab1Here=probabs[0], probab2Here=probabs[1],probab3Here=probabs[2])
            # Generate html for the email
            html = """<html><body>
                <p>Hello User,<br>
                   Your sent email has been tagged as {tag}<br>
                    The probabilities for these tags are as follows<br>
                                {probabs}
                    Thank You for using this Service<br>
                Yours Faithfully,<br>
                    Anti Scam/Spam Bot
                </p></body></html>"""

        # Turn these into plain/html MIMEText objects
        plainText = MIMEText(text, "plain")
        htmlText = MIMEText(html, "html")

        return plainText,htmlText


    #Function to send the email once made
    def sendEmail(self,message,receiver):
        #create secure connection with email server
        with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=(ssl.create_default_context())) as server:
            server.login(self.username, self.password)
            #send email
            #print(receiver,message.as_string())
            server.sendmail(self.username, receiver, message.as_string())